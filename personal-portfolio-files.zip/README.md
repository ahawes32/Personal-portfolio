# Personal Portfolio Website

This is my personal portfolio website showcasing my projects, background, and contact information.

## Features
- Clean responsive layout
- About section
- Project showcase
- Contact info

## Future Plans
- Add more projects
- Deploy with GitHub Pages